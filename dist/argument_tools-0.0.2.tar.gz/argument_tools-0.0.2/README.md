Contains some fairly basic utilities which seem to be required in a number of projects on Argument Mining. 

Namely, a simple way to plot argument graphs, and tools for converting graphs between different formats.


 
