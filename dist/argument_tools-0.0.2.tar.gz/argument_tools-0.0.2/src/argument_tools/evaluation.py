

def evaluation_loop():
    